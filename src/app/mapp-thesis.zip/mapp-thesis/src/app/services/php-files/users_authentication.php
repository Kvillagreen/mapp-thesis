<?php
// login.php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0); // Handle preflight request
}

include 'connection.php';  // Include your database connection

// Get POST data
$data = json_decode(file_get_contents("php://input"), true);
$email = $data['email'] ?? '';
$password = $data['password'] ?? '';

// Query to check if email exists
$sql = "SELECT * FROM tbl_users WHERE Email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

// Check if email exists and password matches
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    if (password_verify($password, $user['Password'])) {
        // Return success response with user data and tokenId
        echo json_encode([
            'success' => true,
            'message' => 'Login successful',
            'user' => [
                'username' => $user['Username'],
                'userId' => $user['user_info_id'],
                'email' => $user['Email'],
                'firstname' => $user['First_name'],
                'lastname' => $user['Last_name'],
            ],
            'tokenId' => $user['tokenId'],
            'status' => $user['status'],
            'userType' => $user['User_type'], 
            
            'events' => $user['access_permissions_events'],
            'transactions' => $user['access_permissions_transactions'],
            'reports' => $user['access_permissions_reports'], 
            'history' => $user['access_permissions_user_settings'],
            'settings' => $user['access_permissions_access_control'],
            'control' => $user['access_permissions_history'], 
        ]);
    } else {
        // Invalid password response
        echo json_encode(['success' => false, 'message' => 'Invalid password']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Data not found']);
}

$conn->close();
?>